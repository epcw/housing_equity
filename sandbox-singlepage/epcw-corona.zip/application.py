import dash
import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Input, Output
import pandas as pd
import plotly.graph_objects as go
import datetime

app = dash.Dash(__name__)
# Beanstalk looks for application by default, if this isn't set you will get a WSGI error.
application = app.server
app.title = "COVID-19 tracker | EPCW"

#this pulls in the header HTML from header.py
from header import Header
top = Header()
app.index_string = top

#read in the json from covidtracking.  You can also do df=pd.read_csv('CSVFILE') for csvs
df= pd.read_json('https://covidtracking.com/api/v1/states/daily.json')

#convert the date format from YYYYMMDD to YYYY-MM-DD because Dash can only handle the latter
df["date"] = pd.to_datetime(df["date"], format = "%Y%m%d").dt.strftime('%Y-%m-%d')
df["pct_positive"] = df["positive"] / df["total"]
df.loc[df['pct_positive'] >= 1] = ''
df["pct_positive"] = (df['pct_positive'] * 100).astype(str).add( '%')

#generate a table if you want this.  Else just comment out  56 rows because states+territories for this dataset If you really need to style this, can add some classes.
def generate_table(dataframe, max_rows=56):
    return html.Table([
        html.Thead(
            html.Tr([html.Th(col) for col in dataframe.columns])
        ),
        html.Tbody([
            html.Tr([
                html.Td(dataframe.iloc[i][col]) for col in dataframe.columns
            ]) for i in range(min(len(dataframe), max_rows))
        ])
    ])

#here we make the graph a function called serve_layout(), which then allows us to have it run every time the page is loaded (unlike the normal which would just be app.layer = GRAPH CONTENT, which would run every time the app was started on the server (aka, once))
def serve_layout():
    return html.Div(children=[
        html.H1(children='US COVID-19 stats over time'),

        html.Div(children='''

        '''),html.H3('Dashboard by Center for Equitable Policy in a Changing World', id='subheading'),
        html.Div(id='y-toggle',children=[
        html.H4('Y-axis scale'),
        dcc.RadioItems(
                id='yaxis_type',
                options=[{'label': i, 'value': i} for i in ['Linear', 'Log']],
                value='Linear',
                labelStyle={'display': 'inline-block'}
            )]),
            html.Div(id='data-dropdown',children=[
            html.H4('Data Selection'),
            dcc.Dropdown(
                    id='data_selection',
                    options=[{'label': i, 'value': i} for i in [
                    'Deaths (Cumulative)',
                    'Hospitalizations (Cumulative)',
                    'Percent of Positive Tests (Cumulative)',
                    'Total Tests (Cumulative)',
                    'Deaths (Daily)',
                    'Hospitalizations (Daily)',
                    'Total Tests (Daily)',
                    ]],
                    value='Deaths (Cumulative)'
                    )]),
        dcc.Graph(
            id='covid_19'
        )#, generate_table(df)
    ])

#this calls the serve_layout function to run on app load.
app.layout = serve_layout

#callbacks for options
#log vs. linear toggler
@app.callback(
    Output('covid_19', 'figure'),
    [Input('yaxis_type', 'value'),Input('data_selection', 'value')])

#updates graph based on user input
def update_graph(yaxis_type,data_selection):
    return {
                'data': [ go.Scatter (
                    x=df[df['state'] == i]['date'],
                    y=df[df['state'] == i][
                    'hospitalized' if data_selection == 'Hospitalizations (Cumulative)'
                    else ('pct_positive' if data_selection == 'Percent of Positive Tests (Cumulative)'
                    else ('total' if data_selection == 'Total Tests (Cumulative)'
                    else ('deathIncrease' if data_selection == 'Deaths (Daily)'
                    else ('hospitalizedIncrease' if data_selection == 'Hospitalizations (Daily)'
                    else ('totalTestResultsIncrease' if data_selection == 'Total Tests (Daily)'
                    else 'death')))))],
                    mode='lines',
                    opacity=1,
                    name=i)
                    for i in df.state.unique()
                ],
                'layout': go.Layout (
                    title='Data source - covidtracking.com, updated 4pm PDT daily',
                    yaxis={'type': 'linear' if yaxis_type == 'Linear' else 'log',
                    'title':
                    'Hospitalizations (Cumulative)' if data_selection == 'Hospitalizations (Cumulative)'
                    else ('Percent of Positive Tests (Cumulative)' if data_selection == 'Percent of Positive Tests (Cumulative)'
                    else ('Total Tests (Cumulative)' if data_selection == 'Total Tests (Cumulative)'
                    else ('Deaths (Daily)' if data_selection == 'Deaths (Daily)'
                    else ('Hospitalizations (Daily)' if data_selection == 'Hospitalizations (Daily)'
                    else ('Total Tests (Daily)' if data_selection == 'Total Tests (Daily)'
                    else 'Deaths (Cumulative)')))))}, #axes options here https://plotly.com/python/axes/
                    xaxis={'type': 'date'}
                )
            }




if __name__ == '__main__':
    # Beanstalk expects it to be running on 8080.
    application.run(debug=True, port=8080)
